# Changelog

## 0.1.3

- Reuse compiled glass programs across navigation, menu, and header transitions.
- Reduce detached backdrop work and stabilize adaptive toolbar, sidebar, and floating-search transitions.

## 0.1.2

- Add adaptive top tabs, native sidebar transitions, and fullscreen overlays above adaptive navigation.
- Improve sidebar materials, content sampling, and navigation glass rendering performance.

## 0.1.1

- Reduce active navigation tab rendering work by sharing scene and lens programs.
- Reuse tab programs and build atlas shader sources lazily.

## 0.1.0

Initial Android Compose framework extraction from MeiloX.

- Introduce Core, Glass, UI, Scaffold, Preference, and Icons modules with one-way dependencies.
- Add light/dark themes, host-configurable colors and typography, and continuous rounded shapes across the component system.
- Preserve backdrop sampling, liquid refraction, press highlights, shadows, navigation contact effects, and menu morph rendering.
- Provide buttons, switches, sliders, segmented controls, text/search fields, steppers, cards, lists, toolbars, navigation bars, menus, alerts, sheets, a color picker, and reorderable groups.
- Add collapsing large-title pages, lazy content, overscroll, pull-refresh rebound, insets, and generic anchor-based sheet state.
- Collapse large titles on a scroll breakpoint (56 dp enter, 24 dp exit) instead of mapping the scroll offset, and play the collapse with the navigation spring. `rememberGlasmioGridCollapseProgress` keeps its name but returns the animated breakpoint value; `rememberGlasmioHeaderScrollEdge` exposes the still-continuous top-bar material progress.
- Separate preference presentation from persistence and symbol rendering from application resources.
- Provide one root-level SF symbol font provider, a replaceable icon resolver, and a local debug font option for the sample.
- Add an independent interactive sample and documentation for component use, backdrop hosting, and migration.
- Unify standalone glass under the navigation renderer with Regular Small, Regular Medium, Regular Large, and Clear scene presets from Apple's Materials page.
- Preserve the original calibrated navigation defaults and complete outline, side-shadow, inner-shadow and shadow-lift layers; scene overrides remain opt-in.
- Add Home, Materials, Settings, and About tabs, reusable floating search, collapsing titles, progressive edge blur, root-tab fades, and Miuix detail-page transitions.
- Use solid catalog backgrounds and the original light/dark iOS 27 wallpaper in glass demonstrations.
- Match the reference text metrics, tracking, control label weights, and continuous corners.
- Add eleven semantic text styles, 34 emphasis/italic variants, and all twelve Dynamic Type categories.
- Match tall swipe actions, structural separators, reorder handles, Alert field spacing, and Stepper press clipping.
- Return plain Pop-up menus to their live text source, preserve corner tangents on tall menus, and retain four-sided shadows through opening and dismissal.
- Retain source-material shadows and interpolate backdrop frost and tint when glass menus return to their toolbar or button.
- Add compact and expanded text editing menus, real 16 dp selection handles, and a Clear cursor magnifier adapted from AndroidLiquidGlass, with safe-area placement and spring following.
- Match the caret loupe to UIKit's glass implementation: a 115 × 85 dp capsule at 1.25× lifted 75 dp above the finger, a 0.3 low-pass into a damping 0.7 / 0.2 s spring, a two-pass opening, a 0.23 s dismissal that collapses the sampled content towards 0.125×, acceleration-driven body deformation with UIKit's tanh soft clamp and live-bounds leading-edge drift, and a dormant line-break dismissal hook. `GlasmioMagnifier` exposes the timings as `GlasmioLoupeMotion`, `rememberGlasmioLoupeFollow` reuses the follower for other lenses, and `docs/ios-loupe-motion.zh-CN.md` records the recovered parameters. The follower keeps UIKit's model and presentation centres apart, and the deformation differentiates absolute velocity the way `prefersDirectionlessAcceleration` does, so a drag in either direction flattens the body and only the drift mirrors.
- Configure signed Maven artifacts, sources, API documentation, and automated Central publication.
- Apache-2.0 license with third-party notices included in every published module.

MeiloX remains responsible for music playback, product navigation, application settings, and player-specific rendering.

