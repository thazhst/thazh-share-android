package io.github.neoruaa.glasmio.glass

import io.github.neoruaa.glasmio.core.*
import io.github.neoruaa.glasmio.icons.*

import android.view.ViewTreeObserver
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.Matrix
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.layer.CompositingStrategy
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.findRootCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionOnScreen
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.github.neoruaa.glasmio.glass.render.Backdrop
import io.github.neoruaa.glasmio.glass.render.backdrops.LayerBackdrop
import io.github.neoruaa.glasmio.glass.render.backdrops.hasBuiltInLayerBlockIndependentSource
import io.github.neoruaa.glasmio.glass.render.backdrops.layerBackdrop
import io.github.neoruaa.glasmio.glass.render.backdrops.rememberLayerBackdrop
import java.lang.ref.WeakReference
import java.util.WeakHashMap
import kotlin.math.ceil

val LocalGlassBackdrop = staticCompositionLocalOf<Backdrop> {
    error("Glass controls must be hosted by GlasmioBackdropHost or GlasmioBackdropProvider")
}

/** Backdrop source reserved for modal surfaces that sample the rendered page. */
val LocalBlurBackdrop = staticCompositionLocalOf<Backdrop> {
    error("Blur glass must be hosted by the app backdrop provider")
}

@Composable
fun GlasmioBackdropProvider(
    backdrop: Backdrop,
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(
        LocalGlassBackdrop provides backdrop,
        LocalBlurBackdrop provides backdrop,
        content = content,
    )
}

/**
 * Keeps sampled content and glass overlays in separate layers. Glass controls must never be
 * placed inside [sampledContent], otherwise the backdrop can recursively sample itself.
 */
@Composable
fun GlasmioBackdropHost(
    modifier: Modifier = Modifier,
    sampledContent: @Composable BoxScope.(LayerBackdrop) -> Unit,
    overlayContent: @Composable BoxScope.(LayerBackdrop) -> Unit,
) = BackdropHost(modifier, uniformFill = false, sampledContent, overlayContent)

/**
 * A [GlasmioBackdropHost] whose sampled content is [sampledColor] filling the host.
 *
 * The host declares the fill itself, so glass that moves while sampling only this color, such as
 * a control in scrolled content, keeps its rendered result instead of repeating every pass.
 * Glass is rendered again as usual when an edge of the fill moves within its samples.
 */
@Composable
fun GlasmioBackdropHost(
    sampledColor: Color,
    modifier: Modifier = Modifier,
    overlayContent: @Composable BoxScope.(LayerBackdrop) -> Unit,
) = BackdropHost(modifier, uniformFill = true, { Box(Modifier.fillMaxSize().background(sampledColor)) }, overlayContent)

@Composable
private fun BackdropHost(
    modifier: Modifier,
    uniformFill: Boolean,
    sampledContent: @Composable BoxScope.(LayerBackdrop) -> Unit,
    overlayContent: @Composable BoxScope.(LayerBackdrop) -> Unit,
) {
    val backdrop = rememberLayerBackdrop()
    // The fill draws nothing else and covers the layer bounds exactly.
    backdrop.fillsBoundsUniformly = uniformFill
    CompositionLocalProvider(
        LocalGlassBackdrop provides backdrop,
        LocalBlurBackdrop provides backdrop,
    ) {
        Box(modifier) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .layerBackdrop(backdrop)
                    .trackBackdropPosition(backdrop),
            ) {
                sampledContent(backdrop)
            }
            overlayContent(backdrop)
        }
    }
}

fun Modifier.glassBackdropSource(backdrop: LayerBackdrop): Modifier = layerBackdrop(backdrop)

/** Weak values prevent modifier callbacks from retaining their backdrop keys and detached trees. */
private val backdropSourcePositions = WeakHashMap<LayerBackdrop, WeakReference<LayoutCoordinates>>()
private val backdropSourceFrames = WeakHashMap<LayerBackdrop, State<Int>>()

/** Attach next to a [layerBackdrop] recording so dialog-window glass can locate the source. */
fun Modifier.trackBackdropPosition(backdrop: LayerBackdrop, frameVersion: State<Int>? = null): Modifier {
    frameVersion?.let { backdropSourceFrames[backdrop] = it }
    return onGloballyPositioned { coordinates ->
        if (coordinates.isAttached) {
            backdropSourcePositions[backdrop] = WeakReference(coordinates)
        }
    }
}

/**
 * Samples a [LayerBackdrop] that was recorded in another window (e.g. app content from a
 * dialog/sheet window). LayerBackdrop maps coordinates with localPositionOf, which cannot
 * cross compose owners and silently yields a wrong offset there, so glass in a dialog
 * samples nothing. Map through screen coordinates so ancestor transforms, including
 * predictive-back scaling, are preserved across windows.
 */
class CrossWindowBackdrop(
    private val source: LayerBackdrop,
    private val rasterized: GraphicsLayer? = null,
    private val renderScale: Float = 1f,
    private val captureHeight: Dp? = null,
    private val sourceFrame: State<Int>? = null,
) : Backdrop {

    private val sourceToGlass = Matrix()
    private val screenToGlass = Matrix()
    private var recordedSourceSize = IntSize.Zero
    private var recordedSourceFrame: Int? = null

    override val isCoordinatesDependent: Boolean get() = true

    override fun observeSourceChanges(observer: () -> Unit): () -> Unit = source.observeSourceChanges(observer)

    override fun DrawScope.drawBackdrop(
        density: Density,
        coordinates: LayoutCoordinates?,
        layerBlock: (GraphicsLayerScope.() -> Unit)?,
    ) {
        val glassCoordinates = coordinates ?: return
        if (!glassCoordinates.isAttached) return
        val sourceCoordinates = backdropSourcePositions[source]?.get()?.takeIf { it.isAttached } ?: return
        // A window draw includes foreground changes isolated in child graphics layers.
        val frame = if (glassCoordinates.findRootCoordinates() !== sourceCoordinates.findRootCoordinates()) {
            (sourceFrame ?: backdropSourceFrames[source])?.value
        } else null
        val sourceSize = source.graphicsLayer.size
        val captureTop = captureHeight?.let {
            (sourceSize.height - with(density) { it.roundToPx() }).coerceAtLeast(0)
        } ?: 0
        val layer = rasterized?.also { cached ->
            val bufferSize = IntSize(
                ceil(sourceSize.width * renderScale).toInt(),
                ceil((sourceSize.height - captureTop) * renderScale).toInt(),
            )
            if (bufferSize.width <= 0 || bufferSize.height <= 0) return
            if (cached.size != bufferSize || recordedSourceSize != sourceSize ||
                (frame != null && recordedSourceFrame != frame)
            ) {
                cached.clip = true
                cached.compositingStrategy = CompositingStrategy.Offscreen
                cached.record(bufferSize) {
                    withTransform({
                        scale(renderScale, renderScale, Offset.Zero)
                        translate(0f, -captureTop.toFloat())
                    }) {
                        drawLayer(source.graphicsLayer)
                    }
                }
                recordedSourceSize = sourceSize
                recordedSourceFrame = frame
            }
        } ?: source.graphicsLayer
        // Include ancestor scale/translation so the sampled page stays screen-anchored
        // while the sheet shrinks during predictive back. This also includes layerBlock.
        sourceToGlass.reset()
        sourceCoordinates.transformToScreen(sourceToGlass)
        screenToGlass.reset()
        glassCoordinates.transformToScreen(screenToGlass)
        screenToGlass.invert()
        sourceToGlass *= screenToGlass
        withTransform({
            transform(sourceToGlass)
            translate(0f, captureTop.toFloat())
            if (rasterized != null) scale(1f / renderScale, 1f / renderScale, Offset.Zero)
        }) {
            drawLayer(layer)
        }
    }
}

/**
 * Wraps a [LayerBackdrop] for glass rendered in a separate window (dialog/sheet).
 * Non-layer backdrops pass through unchanged.
 */
@Composable
fun rememberCrossWindowBackdrop(backdrop: Backdrop): Backdrop = remember(backdrop) {
    if (backdrop is LayerBackdrop) CrossWindowBackdrop(backdrop) else backdrop
}

/** Samples from a stable host while only the glass outline follows its animated layer. */
@Composable
fun rememberStationaryBackdrop(
    backdrop: Backdrop,
    samplingCoordinates: () -> LayoutCoordinates?,
): Backdrop {
    val source = rememberCrossWindowBackdrop(backdrop)
    return remember(source, samplingCoordinates) { StationaryBackdrop(source, samplingCoordinates) }
}

private class StationaryBackdrop(
    private val source: Backdrop,
    private val samplingCoordinates: () -> LayoutCoordinates?,
) : Backdrop {
    private val layerScope = GraphicsLayerBlockScope()
    private val inverseLayer = Matrix()

    override val isCoordinatesDependent: Boolean get() = true

    override fun observeSourceChanges(observer: () -> Unit): () -> Unit = source.observeSourceChanges(observer)

    override fun DrawScope.drawBackdrop(
        density: Density,
        coordinates: LayoutCoordinates?,
        layerBlock: (GraphicsLayerScope.() -> Unit)?,
    ) {
        val host = samplingCoordinates()?.takeIf { it.isAttached } ?: return
        inverseLayer.reset()
        if (layerBlock != null) {
            // Evaluate the live block during recording as well as graphicsLayer updates.
            // This observes animation state and avoids reading an OwnedLayer matrix that
            // may still contain the previous frame's scale or moving pivot.
            layerScope.reset(density, Size(host.size.width.toFloat(), host.size.height.toFloat()))
            layerBlock(layerScope)
            inverseLayer.resetToPivotedTransform(
                pivotX = layerScope.size.width * layerScope.transformOrigin.pivotFractionX,
                pivotY = layerScope.size.height * layerScope.transformOrigin.pivotFractionY,
                translationX = layerScope.translationX,
                translationY = layerScope.translationY,
                rotationX = layerScope.rotationX,
                rotationY = layerScope.rotationY,
                rotationZ = layerScope.rotationZ,
                scaleX = layerScope.scaleX,
                scaleY = layerScope.scaleY,
            )
            inverseLayer.invert()
        }
        withTransform({ transform(inverseLayer) }) {
            // The host sits outside the animated layer. Passing null prevents source
            // backdrops from applying the same inverse transform a second time.
            with(source) { drawBackdrop(density, host, null) }
        }
    }
}

/** Share a live, flattened player source between modal glass and its small glass controls. */
@Composable
fun rememberRasterizedBackdrop(source: LayerBackdrop): Backdrop {
    val rasterized = rememberGraphicsLayer()
    val view = LocalView.current
    val sourceFrame = remember(view) { mutableIntStateOf(0) }
    DisposableEffect(view, sourceFrame) {
        var frame = 0
        val listener = ViewTreeObserver.OnPreDrawListener {
            // Only cross-window drawing observes this state; the source stays independent.
            sourceFrame.intValue = ++frame
            true
        }
        view.viewTreeObserver.addOnPreDrawListener(listener)
        onDispose {
            val observer = view.viewTreeObserver
            if (observer.isAlive) observer.removeOnPreDrawListener(listener)
        }
    }
    return remember(source, rasterized, sourceFrame) {
        CrossWindowBackdrop(source, rasterized, renderScale = 0.25f, sourceFrame = sourceFrame)
    }
}

/**
 * Share rasterized page regions between glass consumers instead of replaying the display
 * list (including nested blur and navigation layers) for every lens. This is a live layer
 * reference: source changes invalidate the GPU cache even when the recording is unchanged.
 * Only sampled pixels use half resolution; text, glass outlines and highlights stay native.
 */
@Composable
fun rememberSharedGlassBackdrop(base: Backdrop, source: LayerBackdrop): Backdrop {
    val full = rememberGraphicsLayer()
    val bottom = rememberGraphicsLayer()
    return remember(base, source, full, bottom) {
        SharedGlassBackdrop(base, source, full, bottom)
    }
}

/** A morph records in root coordinates, but only needs pixels inside its capture viewport. */
interface ViewportBackdrop : Backdrop {
    fun DrawScope.drawViewport(density: Density, coordinates: LayoutCoordinates, viewport: Rect)
}

/** Only these final wrappers map actual coordinates without evaluating the layer block. */
internal fun Backdrop.hasBuiltInGlassLayerBlockIndependentSource(): Boolean = when (this) {
    is CrossWindowBackdrop -> true
    is SharedGlassBackdrop -> hasLayerBlockIndependentBase()
    else -> false
}

private val BottomCaptureHeight = 240.dp

private class SharedGlassBackdrop(
    private val base: Backdrop,
    private val source: LayerBackdrop,
    fullLayer: GraphicsLayer,
    bottomLayer: GraphicsLayer,
) : ViewportBackdrop {
    private val full = CrossWindowBackdrop(source, fullLayer, renderScale = 0.5f)
    private val bottom = CrossWindowBackdrop(source, bottomLayer, renderScale = 0.5f,
        captureHeight = BottomCaptureHeight)

    internal fun hasLayerBlockIndependentBase(): Boolean = base.hasBuiltInLayerBlockIndependentSource()

    override val isCoordinatesDependent: Boolean get() = true

    override fun observeSourceChanges(observer: () -> Unit): () -> Unit {
        if (base === source) return source.observeSourceChanges(observer)
        val baseObservation = base.observeSourceChanges(observer)
        val sourceObservation = source.observeSourceChanges(observer)
        return { baseObservation(); sourceObservation() }
    }

    private fun sample(density: Density, coordinates: LayoutCoordinates?, top: Float): Backdrop {
        val recorded = backdropSourcePositions[source]?.get()
        if (coordinates?.isAttached != true || recorded?.isAttached != true) return full
        val sourceTop = coordinates.positionOnScreen().y - recorded.positionOnScreen().y + top
        val bandTop = source.graphicsLayer.size.height - with(density) { BottomCaptureHeight.toPx() }
        // Include the largest navigation lens/blur padding. Upper controls and full-sheet
        // captures use the full page; bottom morphs never replay the top toolbar's blur.
        return if (sourceTop - with(density) { 32.dp.toPx() } >= bandTop) bottom else full
    }

    override fun DrawScope.drawBackdrop(
        density: Density,
        coordinates: LayoutCoordinates?,
        layerBlock: (GraphicsLayerScope.() -> Unit)?,
    ) {
        with(base) { drawBackdrop(density, coordinates, layerBlock) }
        with(sample(density, coordinates, 0f)) { drawBackdrop(density, coordinates, layerBlock) }
    }

    override fun DrawScope.drawViewport(
        density: Density,
        coordinates: LayoutCoordinates,
        viewport: Rect,
    ) {
        with(base) { drawBackdrop(density, coordinates, null) }
        with(sample(density, coordinates, viewport.top)) { drawBackdrop(density, coordinates, null) }
    }
}
